# luci-app-dbus-sms 1.0.0

ImmortalWrt 25.10 package using APK when `CONFIG_USE_APK=y`.

It integrates the upstream `DbusSmsForwardCPlus` binary into the same package and adds:

- LuCI service control
- SMS sending through the upstream `/api` endpoint
- Received SMS history through the upstream shell-forward mode
- Automatic service startup
- API port configuration (default 8080)

The upstream source is downloaded from GitHub during the ImmortalWrt build, then cross-compiled with the target toolchain. It is therefore a single installed package, but the source archive itself does not vendor the upstream repository.

Build:

    cp -a luci-app-dbus-sms package/luci-app-dbus-sms
    make menuconfig
    make package/luci-app-dbus-sms/compile V=s

With `CONFIG_USE_APK=y`, ImmortalWrt's package system emits an `.apk`; otherwise it emits an `.ipk`. The package format is controlled by the firmware build configuration, not by the package directory itself.
