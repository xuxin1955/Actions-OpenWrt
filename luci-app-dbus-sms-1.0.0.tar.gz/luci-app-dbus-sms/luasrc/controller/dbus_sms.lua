module("luci.controller.dbus_sms", package.seeall)

function index()
	if not nixio.fs.access("/etc/config/dbus-sms") then return end
	entry({"admin", "services", "dbus-sms"}, cbi("dbus-sms"), _("短信管理"), 70).dependent = true
	entry({"admin", "services", "dbus-sms", "inbox"}, template("dbus-sms/inbox"), _("收件箱"), 10)
end
