local m = Map("dbus-sms", translate("短信管理"), translate("DbusSmsForwardCPlus 一体化短信服务"))

local s = m:section(NamedSection, "main", "dbus-sms", translate("服务设置"))
s.anonymous = true

o = s:option(Flag, "enabled", translate("启用服务"))
o.rmempty = false

o = s:option(Value, "api_port", translate("短信 API 端口"))
o.datatype = "port"
o.default = "8080"

o = s:option(DummyValue, "status", translate("运行状态"))
o.template = "dbus-sms/status"

local send = m:section(SimpleSection, nil, translate("发送短信"))
local to = send:option(Value, "telnum", translate("号码"))
to.placeholder = "10010"
local body = send:option(TextValue, "smstext", translate("内容"))
body.rows = 5
body.wrap = "off"
local btn = send:option(Button, "send", translate("发送"))
btn.inputstyle = "apply"
function btn.write(self, section)
	local http = require("luci.http")
	local sys = require("luci.sys")
	local port = uci:get("dbus-sms", "main", "api_port") or "8080"
	local tel = http.formvalue("cbid.dbus-sms.main.telnum") or ""
	local text = http.formvalue("cbid.dbus-sms.main.smstext") or ""
	if tel == "" or text == "" then
		http.redirect(luci.dispatcher.build_url("admin/services/dbus-sms"))
		return
	end
	local function urlencode(s)
		return (s:gsub("([^%w%-_%.~])", function(c) return string.format("%%%02X", string.byte(c)) end))
	end
	local cmd = string.format("uclient-fetch -qO- 'http://127.0.0.1:%s/api?telnum=%s&smstext=%s' >/dev/null 2>&1", port, urlencode(tel), urlencode(text))
	sys.call(cmd)
	http.redirect(luci.dispatcher.build_url("admin/services/dbus-sms"))
end

return m
