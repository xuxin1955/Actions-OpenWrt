#!/bin/sh
# DbusSmsForwardCPlus shell-forward callback.
# Arguments: telnum smsdate smscontent smscode smscodefrom devicename
set -eu

mkdir -p /etc/dbus-sms
umask 077
log=/etc/dbus-sms/inbox.log

# Keep one tab-separated record per received SMS. Escape literal tabs/newlines.
sanitize() {
	echo "$1" | tr '\t\r\n' '   '
}

printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
	"$(sanitize "${1:-}")" \
	"$(sanitize "${2:-}")" \
	"$(sanitize "${3:-}")" \
	"$(sanitize "${4:-}")" \
	"$(sanitize "${5:-}")" \
	"$(sanitize "${6:-}")" >> "$log"

# Keep the last 200 messages on small routers.
tail -n 200 "$log" > "$log.tmp" 2>/dev/null || true
mv "$log.tmp" "$log" 2>/dev/null || true
